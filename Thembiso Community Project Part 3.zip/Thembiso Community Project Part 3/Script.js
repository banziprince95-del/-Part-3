<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DynamicSEO · Interactive Forms & Animations</title>
  <!-- SEO Meta Tags -->
  <meta name="description" content="Dynamic landing page with SEO best practices, interactive forms, client-side validation, animations, Google Maps and YouTube embeds.">
  <meta name="keywords" content="dynamic, animations, interactive forms, SEO, javascript, validation, google maps, youtube, embed">
  <meta name="author" content="SEO Dynamic">
  <link rel="canonical" href="https://dynamicseo.example.com">
  <!-- Open Graph -->
  <meta property="og:title" content="DynamicSEO – animations, forms & embeds">
  <meta property="og:description" content="Interactive page with client-side validation, Google Maps & YouTube, built with SEO in mind.">
  <meta property="og:type" content="website">
  <!-- Font Awesome (icons) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Roboto, system-ui, sans-serif;
    }
    body {
      background: #f4f7fc;
      color: #1e2b3c;
      padding: 2rem 1.5rem;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .container {
      max-width: 1200px;
      width: 100%;
    }
    /* ----- animations (dynamic) ----- */
    .hero {
      background: linear-gradient(145deg, #0b2a3e, #1c4e6f);
      color: white;
      padding: 2.5rem 2rem;
      border-radius: 32px;
      margin-bottom: 2.5rem;
      box-shadow: 0 15px 30px rgba(0,20,30,0.3);
      transition: transform 0.2s ease;
      animation: floatIn 1s ease-out;
    }
    @keyframes floatIn {
      0% { opacity: 0; transform: translateY(-30px) scale(0.97); }
      100% { opacity: 1; transform: translateY(0) scale(1); }
    }
    .hero h1 {
      font-size: 2.8rem;
      font-weight: 600;
      letter-spacing: -0.5px;
      display: flex;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
    }
    .hero h1 i {
      color: #ffd966;
      font-size: 2.6rem;
      animation: pulseGlow 2.4s infinite;
    }
    @keyframes pulseGlow {
      0% { text-shadow: 0 0 5px #ffd966; }
      50% { text-shadow: 0 0 20px #ffb347, 0 0 40px #ff8c00; }
      100% { text-shadow: 0 0 5px #ffd966; }
    }
    .hero p {
      font-size: 1.2rem;
      opacity: 0.9;
      margin-top: 0.5rem;
      max-width: 700px;
    }
    .section-title {
      font-size: 2rem;
      font-weight: 600;
      margin: 2rem 0 1.2rem;
      border-left: 6px solid #1c6f8c;
      padding-left: 1rem;
      color: #0a2a3b;
    }
    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
      margin-bottom: 2rem;
    }
    .card {
      background: white;
      border-radius: 28px;
      padding: 1.8rem 1.5rem;
      box-shadow: 0 10px 20px rgba(0,0,0,0.04);
      transition: all 0.25s ease;
      border: 1px solid rgba(0,0,0,0.02);
      animation: cardPop 0.5s ease backwards;
      animation-delay: calc(0.1s * var(--i, 1));
    }
    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 30px rgba(0, 40, 60, 0.12);
      border-color: #cbdde8;
    }
    @keyframes cardPop {
      0% { opacity: 0; transform: scale(0.94); }
      100% { opacity: 1; transform: scale(1); }
    }
    .card h3 {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.5rem;
      margin-bottom: 1rem;
      color: #1a4b63;
    }
    .card h3 i {
      color: #2a7f9e;
      font-size: 1.6rem;
    }
    /* forms */
    .form-group {
      margin-bottom: 1.2rem;
    }
    label {
      display: block;
      font-weight: 500;
      margin-bottom: 0.3rem;
      color: #1e3b4b;
    }
    input, textarea, select {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 1.5px solid #dce8f0;
      border-radius: 40px;
      font-size: 1rem;
      transition: 0.2s;
      background: #fafcfe;
    }
    input:focus, textarea:focus, select:focus {
      outline: none;
      border-color: #1c7a9e;
      box-shadow: 0 0 0 4px rgba(28, 122, 158, 0.15);
    }
    textarea {
      border-radius: 24px;
      resize: vertical;
      min-height: 80px;
    }
    .btn {
      background: #1a5e7a;
      color: white;
      border: none;
      padding: 0.8rem 2rem;
      border-radius: 60px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: 0.2s;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 6px 12px rgba(20,80,110,0.2);
    }
    .btn:hover {
      background: #0f4a61;
      transform: scale(1.02);
      box-shadow: 0 10px 18px rgba(20,80,110,0.3);
    }
    .btn i {
      font-size: 1.1rem;
    }
    .validation-feedback {
      color: #c0392b;
      font-size: 0.9rem;
      margin-top: 0.3rem;
      display: none;
    }
    .validation-feedback.show {
      display: block;
    }
    .form-row {
      display: flex;
      flex-wrap: wrap;
      gap: 1rem;
    }
    .form-row .form-group {
      flex: 1 1 180px;
    }
    .success-message {
      background: #d4edda;
      color: #155724;
      padding: 0.8rem 1.2rem;
      border-radius: 40px;
      margin-top: 1rem;
      display: none;
      font-weight: 500;
    }
    .success-message.show {
      display: block;
      animation: fadeSlide 0.4s;
    }
    @keyframes fadeSlide {
      0% { opacity: 0; transform: translateY(10px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    /* embeds */
    .embed-wrapper {
      background: white;
      border-radius: 28px;
      padding: 1.2rem;
      box-shadow: 0 6px 18px rgba(0,0,0,0.04);
      border: 1px solid #e9f0f5;
      margin: 1.5rem 0;
    }
    .embed-wrapper iframe {
      width: 100%;
      border-radius: 18px;
      display: block;
    }
    .map-placeholder {
      height: 280px;
      background: #d4e2ed;
      border-radius: 18px;
      overflow: hidden;
    }
    .flex-embeds {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1.5rem;
    }
    @media (max-width: 700px) {
      .flex-embeds {
        grid-template-columns: 1fr;
      }
    }
    .footer {
      margin-top: 3rem;
      padding-top: 1.5rem;
      border-top: 1px solid #cbdae6;
      text-align: center;
      color: #3b5d70;
    }
    .alt-example {
      font-size: 0.85rem;
      background: #eef4f9;
      padding: 0.4rem 1rem;
      border-radius: 30px;
      display: inline-block;
      margin-top: 0.5rem;
    }
    /* interactive dynamic element (JS animated badge) */
    .dynamic-badge {
      background: #ffd966;
      color: #1e3b4b;
      padding: 0.3rem 1.2rem;
      border-radius: 60px;
      font-weight: 600;
      display: inline-block;
      margin-top: 0.8rem;
      transition: 0.3s;
      box-shadow: 0 2px 8px rgba(255, 200, 0, 0.3);
    }
    .dynamic-badge i {
      margin-right: 6px;
    }
  </style>
</head>
<body>
<div class="container">

  <!-- HERO with animation and keyword -->
  <header class="hero">
    <h1>
      <i class="fas fa-rocket" alt="Rocket icon"></i> 
      Dynamic<span style="color:#ffd966;">SEO</span>
    </h1>
    <p>Interactive forms · client-side validation · animated elements · Google Maps & YouTube embeds</p>
    <div class="dynamic-badge" id="liveBadge">
      <i class="fas fa-circle" style="color:#22c55e; font-size: 0.7rem;"></i> 
      <span id="badgeText">live & interactive</span>
    </div>
  </header>

  <!-- ====== INTERACTIVE FORM with client-side validation ====== -->
  <section aria-label="Interactive contact form">
    <h2 class="section-title"><i class="fas fa-pen-to-square" style="margin-right: 12px;"></i>Get in touch</h2>
    <div class="card">
      <form id="contactForm" novalidate>
        <div class="form-row">
          <div class="form-group">
            <label for="fullName"><i class="fas fa-user"></i> Full Name *</label>
            <input type="text" id="fullName" placeholder="Jane Doe" required aria-required="true">
            <div class="validation-feedback" id="nameFeedback">Please enter your full name (min 2 chars).</div>
          </div>
          <div class="form-group">
            <label for="email"><i class="fas fa-envelope"></i> Email *</label>
            <input type="email" id="email" placeholder="jane@example.com" required>
            <div class="validation-feedback" id="emailFeedback">Enter a valid email address.</div>
          </div>
        </div>
        <div class="form-group">
          <label for="interest"><i class="fas fa-tag"></i> Topic</label>
          <select id="interest">
            <option value="general">General inquiry</option>
            <option value="seo">SEO consultation</option>
            <option value="animations">Animation demo</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div class="form-group">
          <label for="message"><i class="fas fa-comment"></i> Message *</label>
          <textarea id="message" placeholder="Tell us what you think..." required minlength="5"></textarea>
          <div class="validation-feedback" id="msgFeedback">Message must be at least 5 characters.</div>
        </div>
        <button type="submit" class="btn"><i class="fas fa-paper-plane"></i> Submit</button>
        <div class="success-message" id="formSuccess"><i class="fas fa-check-circle"></i> Thanks! Your message was sent (demo).</div>
      </form>
    </div>
  </section>

  <!-- ====== EXTERNAL CONTENT: Google Maps + YouTube ====== -->
  <section aria-label="Embedded content from external sources">
    <h2 class="section-title"><i class="fas fa-globe"></i> External content</h2>
    <div class="flex-embeds">
      <!-- Google Maps embed -->
      <div class="embed-wrapper">
        <h3 style="display: flex; align-items: center; gap: 8px; margin-bottom: 0.8rem;">
          <i class="fas fa-map-pin" style="color:#1a7a5e;"></i> Google Maps
        </h3>
        <div class="map-placeholder">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.2219901290355!2d-74.00369368400567!3d40.71312937933038!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a316bb7ae1f%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1619521424556!5m2!1sen!2sus" 
            width="100%" 
            height="280" 
            style="border:0; border-radius: 18px;" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade"
            title="Google Map of Downtown Conference Center, NYC"
            alt="Google Map showing Downtown Conference Center location"
          ></iframe>
        </div>
        <div class="alt-example"><i class="fas fa-info-circle"></i> alt text: "Google Map showing Downtown Conference Center location"</div>
      </div>

      <!-- YouTube embed -->
      <div class="embed-wrapper">
        <h3 style="display: flex; align-items: center; gap: 8px; margin-bottom: 0.8rem;">
          <i class="fab fa-youtube" style="color:#cc181e;"></i> YouTube
        </h3>
        <div style="border-radius: 18px; overflow: hidden; aspect-ratio: 16/9;">
          <iframe 
            src="https://www.youtube.com/embed/9bZkp7q19f0?si=9jEAt9TVlPqH6xGc" 
            title="YouTube video: PSY - GANGNAM STYLE (animated example)" 
            frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen
            style="width:100%; height:100%; border:0;"
            loading="lazy"
          ></iframe>
        </div>
        <div class="alt-example"><i class="fas fa-info-circle"></i> alt text: "YouTube video: PSY - GANGNAM STYLE (animated example)"</div>
      </div>
    </div>
  </section>

  <!-- ====== DYNAMIC ELEMENTS (JS animations / interactive) ====== -->
  <section aria-label="Dynamic animations and interactive elements">
    <h2 class="section-title"><i class="fas fa-bolt"></i> Dynamic & interactive</h2>
    <div class="card-grid">
      <div class="card" style="--i:1;">
        <h3><i class="fas fa-rotate"></i> Animated counter</h3>
        <p>Click the button to see a dynamic count with animation.</p>
        <div style="display: flex; align-items: center; gap: 1.2rem; flex-wrap: wrap;">
          <span id="counterDisplay" style="font-size: 2.8rem; font-weight: 700; color: #0f4a61;">0</span>
          <button class="btn" id="animateCounterBtn" style="background: #2f7c9e;"><i class="fas fa-plus"></i> Animate +5</button>
        </div>
        <div id="counterFeedback" style="margin-top: 0.6rem; font-size: 0.9rem; color: #1f6f8a;"></div>
      </div>
      <div class="card" style="--i:2;">
        <h3><i class="fas fa-hand-pointer"></i> Interactive color</h3>
        <p>Click the box to toggle a dynamic pulse animation.</p>
        <div id="colorBox" style="background: #1f7a9e; padding: 1.2rem; border-radius: 40px; text-align: center; color: white; font-weight: 500; cursor: pointer; transition: 0.2s; box-shadow: 0 6px 14px rgba(0,0,0,0.06);">
          <i class="fas fa-arrows-spin" style="margin-right: 8px;"></i> Click me to pulse
        </div>
        <div id="pulseStatus" style="margin-top: 0.5rem; font-size: 0.9rem; color: #2a5a6e;">waiting for click</div>
      </div>
    </div>
  </section>

  <footer class="footer">
    <p><i class="fas fa-code"></i> Built with dynamic JavaScript · SEO meta, alt texts, keywords · interactive forms & external embeds</p>
    <p style="margin-top: 0.3rem; opacity:0.7;">© 2026 DynamicSEO — all demo content</p>
  </footer>
</div>

<!-- ==================== JAVASCRIPT ==================== -->
<script>
  (function() {
    "use strict";

    // ---------- 1. FORM VALIDATION (client-side) ----------
    const form = document.getElementById('contactForm');
    const nameInput = document.getElementById('fullName');
    const emailInput = document.getElementById('email');
    const msgInput = document.getElementById('message');
    const nameFeedback = document.getElementById('nameFeedback');
    const emailFeedback = document.getElementById('emailFeedback');
    const msgFeedback = document.getElementById('msgFeedback');
    const successMsg = document.getElementById('formSuccess');

    // validation helpers
    function validateName() {
      const val = nameInput.value.trim();
      if (val.length < 2) {
        nameFeedback.classList.add('show');
        return false;
      } else {
        nameFeedback.classList.remove('show');
        return true;
      }
    }
    function validateEmail() {
      const val = emailInput.value.trim();
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!regex.test(val)) {
        emailFeedback.classList.add('show');
        return false;
      } else {
        emailFeedback.classList.remove('show');
        return true;
      }
    }
    function validateMessage() {
      const val = msgInput.value.trim();
      if (val.length < 5) {
        msgFeedback.classList.add('show');
        return false;
      } else {
        msgFeedback.classList.remove('show');
        return true;
      }
    }

    // real-time blur validation
    nameInput.addEventListener('blur', validateName);
    emailInput.addEventListener('blur', validateEmail);
    msgInput.addEventListener('blur', validateMessage);
    // also on input to clear feedback
    nameInput.addEventListener('input', function() {
      if (this.value.trim().length >= 2) nameFeedback.classList.remove('show');
    });
    emailInput.addEventListener('input', function() {
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.value.trim())) emailFeedback.classList.remove('show');
    });
    msgInput.addEventListener('input', function() {
      if (this.value.trim().length >= 5) msgFeedback.classList.remove('show');
    });

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const isNameOk = validateName();
      const isEmailOk = validateEmail();
      const isMsgOk = validateMessage();
      if (isNameOk && isEmailOk && isMsgOk) {
        // success
        successMsg.classList.add('show');
        // optionally reset after 4 sec
        setTimeout(() => {
          successMsg.classList.remove('show');
        }, 4000);
        // (demo: do not actually send)
        console.log('Form valid, would submit.');
      } else {
        // ensure feedback shows
        successMsg.classList.remove('show');
      }
    });

    // ---------- 2. DYNAMIC COUNTER WITH ANIMATION ----------
    let counter = 0;
    const counterDisplay = document.getElementById('counterDisplay');
    const counterBtn = document.getElementById('animateCounterBtn');
    const counterFeedback = document.getElementById('counterFeedback');

    function animateCounter(target) {
      const start = counter;
      const duration = 400; // ms
      const startTime = performance.now();

      function step(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        // easeOutCubic
        const ease = 1 - Math.pow(1 - progress, 3);
        const current = Math.round(start + (target - start) * ease);
        counterDisplay.textContent = current;
        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          counterDisplay.textContent = target;
          counter = target;
          counterFeedback.textContent = `✨ updated to ${target}`;
        }
      }
      requestAnimationFrame(step);
    }

    counterBtn.addEventListener('click', function() {
      const increment = 5;
      const newVal = counter + increment;
      animateCounter(newVal);
      // interactive feedback 
      counterFeedback.style.color = '#1b6b4a';
    });

    // ---------- 3. INTERACTIVE PULSE BOX (dynamic animation) ----------
    const colorBox = document.getElementById('colorBox');
    const pulseStatus = document.getElementById('pulseStatus');
    let pulseActive = false;

    colorBox.addEventListener('click', function() {
      pulseActive = !pulseActive;
      if (pulseActive) {
        this.style.animation = 'pulseGlow 1s infinite';
        this.style.background = '#b96f2b';
        pulseStatus.textContent = '✨ pulse active (click again to stop)';
        pulseStatus.style.color = '#a85f1a';
      } else {
        this.style.animation = 'none';
        this.style.background = '#1f7a9e';
        pulseStatus.textContent = '⏸️ pulse stopped';
        pulseStatus.style.color = '#2a5a6e';
      }
    });

    // ---------- 4. DYNAMIC BADGE (extra interactive) ----------
    const badgeText = document.getElementById('badgeText');
    const liveBadge = document.getElementById('liveBadge');
    let toggle = false;
    setInterval(() => {
      toggle = !toggle;
      if (toggle) {
        badgeText.textContent = '✨ interactive dynamic';
        liveBadge.style.background = '#b8d9e6';
      } else {
        badgeText.textContent = 'live & interactive';
        liveBadge.style.background = '#ffd966';
      }
    }, 2800);

    // 5. small extra: alt text for images (demo) – already in iframe title/alt
    console.log('✅ Dynamic SEO page ready: animations, forms, validation, maps, youtube.');
  })();
</script>

<!-- additional keyword rich content (hidden SEO friendly) -->
<div style="display: none;" aria-hidden="true">
  <!-- keyword rich: animations, interactive forms, SEO, google maps embed, youtube embed, client side validation -->
  <span>dynamic animations interactive forms seo google maps youtube embed client side validation</span>
</div>
</body>
</html>